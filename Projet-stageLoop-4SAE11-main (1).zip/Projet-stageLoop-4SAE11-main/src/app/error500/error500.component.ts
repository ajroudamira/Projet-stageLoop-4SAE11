import { Component } from '@angular/core';

@Component({
  selector: 'app-error500',
  standalone: true,
  imports: [],
  templateUrl: './error500.component.html',
  styleUrl: './error500.component.css'
})
export class Error500Component {

}
